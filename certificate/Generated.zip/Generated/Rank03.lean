import PopTacToe.Generated.Rank03.Chunk000
import PopTacToe.Generated.Rank03.Chunk001
import PopTacToe.Generated.Rank03.Chunk002
import PopTacToe.Generated.Rank03.Chunk003
import PopTacToe.Generated.Rank03.Chunk004
import PopTacToe.Generated.Rank03.Chunk005
import PopTacToe.Generated.Rank03.Chunk006
import PopTacToe.Generated.Rank03.Chunk007
import PopTacToe.Generated.Rank03.Chunk008
import PopTacToe.Generated.Rank03.Chunk009
import PopTacToe.Generated.Rank03.Chunk010
import PopTacToe.Generated.Rank03.Chunk011
import PopTacToe.Generated.Rank03.Chunk012
import PopTacToe.Generated.Rank03.Chunk013
import PopTacToe.Generated.Rank03.Chunk014
import PopTacToe.Generated.Rank03.Chunk015
import PopTacToe.Generated.Rank03.Chunk016
import PopTacToe.Generated.Rank03.Chunk017
import PopTacToe.Generated.Rank03.Chunk018
import PopTacToe.Generated.Rank03.Chunk019
import PopTacToe.Generated.Rank03.Chunk020
import PopTacToe.Generated.Rank03.Chunk021
import PopTacToe.Generated.Rank03.Chunk022
import PopTacToe.Generated.Rank03.Chunk023
import PopTacToe.Generated.Rank03.Chunk024
import PopTacToe.Generated.Rank03.Chunk025
import PopTacToe.Generated.Rank03.Chunk026
import PopTacToe.Generated.Rank03.Chunk027
import PopTacToe.Generated.Rank03.Chunk028
import PopTacToe.Generated.Rank03.Chunk029
import PopTacToe.Generated.Rank03.Chunk030
import PopTacToe.Generated.Rank03.Chunk031
import PopTacToe.Generated.Rank03.Chunk032
import PopTacToe.Generated.Rank03.Chunk033
import PopTacToe.Generated.Rank03.Chunk034
import PopTacToe.Generated.Rank03.Chunk035
import PopTacToe.Generated.Rank03.Chunk036
import PopTacToe.Generated.Rank03.Chunk037
import PopTacToe.Generated.Rank03.Chunk038
import PopTacToe.Generated.Rank03.Chunk039
import PopTacToe.Generated.Rank03.Chunk040
import PopTacToe.Generated.Rank03.Chunk041
import PopTacToe.Generated.Rank03.Chunk042
import PopTacToe.Generated.Rank03.Chunk043
import PopTacToe.Generated.Rank03.Chunk044

namespace PopTacToe.Generated.Rank03

/-- All 705 PTTCERT1 rank-3 states, in certificate order. -/
def chunks : Array (Nat → Option State) :=
  (((((#[Chunk000.lookup] ++ #[Chunk001.lookup]) ++ (#[Chunk002.lookup] ++ (#[Chunk003.lookup] ++ #[Chunk004.lookup]))) ++ ((#[Chunk005.lookup] ++ (#[Chunk006.lookup] ++ #[Chunk007.lookup])) ++ (#[Chunk008.lookup] ++ (#[Chunk009.lookup] ++ #[Chunk010.lookup])))) ++ (((#[Chunk011.lookup] ++ #[Chunk012.lookup]) ++ (#[Chunk013.lookup] ++ (#[Chunk014.lookup] ++ #[Chunk015.lookup]))) ++ ((#[Chunk016.lookup] ++ (#[Chunk017.lookup] ++ #[Chunk018.lookup])) ++ (#[Chunk019.lookup] ++ (#[Chunk020.lookup] ++ #[Chunk021.lookup]))))) ++ ((((#[Chunk022.lookup] ++ #[Chunk023.lookup]) ++ (#[Chunk024.lookup] ++ (#[Chunk025.lookup] ++ #[Chunk026.lookup]))) ++ ((#[Chunk027.lookup] ++ (#[Chunk028.lookup] ++ #[Chunk029.lookup])) ++ (#[Chunk030.lookup] ++ (#[Chunk031.lookup] ++ #[Chunk032.lookup])))) ++ (((#[Chunk033.lookup] ++ (#[Chunk034.lookup] ++ #[Chunk035.lookup])) ++ (#[Chunk036.lookup] ++ (#[Chunk037.lookup] ++ #[Chunk038.lookup]))) ++ ((#[Chunk039.lookup] ++ (#[Chunk040.lookup] ++ #[Chunk041.lookup])) ++ (#[Chunk042.lookup] ++ (#[Chunk043.lookup] ++ #[Chunk044.lookup]))))))

def known : Nat → Option State :=
  chunkedLookup chunks 16

theorem verified : VerifiedLookup 2 known := by
  unfold known
  apply chunkedLookup_verified
  unfold chunks
  exact verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk000.verified) (verifiedChunks_single Chunk001.verified)) (verifiedChunks_append (verifiedChunks_single Chunk002.verified) (verifiedChunks_append (verifiedChunks_single Chunk003.verified) (verifiedChunks_single Chunk004.verified)))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk005.verified) (verifiedChunks_append (verifiedChunks_single Chunk006.verified) (verifiedChunks_single Chunk007.verified))) (verifiedChunks_append (verifiedChunks_single Chunk008.verified) (verifiedChunks_append (verifiedChunks_single Chunk009.verified) (verifiedChunks_single Chunk010.verified))))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk011.verified) (verifiedChunks_single Chunk012.verified)) (verifiedChunks_append (verifiedChunks_single Chunk013.verified) (verifiedChunks_append (verifiedChunks_single Chunk014.verified) (verifiedChunks_single Chunk015.verified)))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk016.verified) (verifiedChunks_append (verifiedChunks_single Chunk017.verified) (verifiedChunks_single Chunk018.verified))) (verifiedChunks_append (verifiedChunks_single Chunk019.verified) (verifiedChunks_append (verifiedChunks_single Chunk020.verified) (verifiedChunks_single Chunk021.verified)))))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk022.verified) (verifiedChunks_single Chunk023.verified)) (verifiedChunks_append (verifiedChunks_single Chunk024.verified) (verifiedChunks_append (verifiedChunks_single Chunk025.verified) (verifiedChunks_single Chunk026.verified)))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk027.verified) (verifiedChunks_append (verifiedChunks_single Chunk028.verified) (verifiedChunks_single Chunk029.verified))) (verifiedChunks_append (verifiedChunks_single Chunk030.verified) (verifiedChunks_append (verifiedChunks_single Chunk031.verified) (verifiedChunks_single Chunk032.verified))))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk033.verified) (verifiedChunks_append (verifiedChunks_single Chunk034.verified) (verifiedChunks_single Chunk035.verified))) (verifiedChunks_append (verifiedChunks_single Chunk036.verified) (verifiedChunks_append (verifiedChunks_single Chunk037.verified) (verifiedChunks_single Chunk038.verified)))) (verifiedChunks_append (verifiedChunks_append (verifiedChunks_single Chunk039.verified) (verifiedChunks_append (verifiedChunks_single Chunk040.verified) (verifiedChunks_single Chunk041.verified))) (verifiedChunks_append (verifiedChunks_single Chunk042.verified) (verifiedChunks_append (verifiedChunks_single Chunk043.verified) (verifiedChunks_single Chunk044.verified))))))

#print axioms verified

end PopTacToe.Generated.Rank03
