import PopTacToe.WitnessedCertificate

namespace PopTacToe.Generated.Base

def known : Nat → Option State := fun _ => none

theorem verified : VerifiedLookup 0 known := by
  simp [VerifiedLookup, known]

#print axioms verified

end PopTacToe.Generated.Base
